import { IItemEventRouterBase } from "./IItemEventRouterBase";
export interface IItemEventRouterResponse extends IItemEventRouterBase {
}
