export interface IPresetCallbacks {
    load(): void;
}
