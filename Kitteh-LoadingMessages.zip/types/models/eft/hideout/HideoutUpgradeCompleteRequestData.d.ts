export interface HideoutUpgradeCompleteRequestData {
    Action: string;
    areaType: number;
    timestamp: number;
}
