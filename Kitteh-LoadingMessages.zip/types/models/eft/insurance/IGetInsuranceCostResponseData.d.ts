export declare type IGetInsuranceCostResponseData = Record<string, Record<string, number>>;
