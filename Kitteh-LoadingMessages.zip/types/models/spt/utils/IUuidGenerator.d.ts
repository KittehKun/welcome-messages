export interface IUUidGenerator {
    generate(): string;
}
