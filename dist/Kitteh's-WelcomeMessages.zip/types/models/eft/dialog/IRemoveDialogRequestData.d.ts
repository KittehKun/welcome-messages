export interface IRemoveDialogRequestData {
    dialogId: string;
}
